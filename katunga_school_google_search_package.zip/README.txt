KATUNGA VOCATIONAL SECONDARY SCHOOL — GOOGLE SEARCH SETUP

Files included:
- katunga_vocational_secondary_school_google_ready.html: updated school website
- robots.txt: allows search-engine crawlers and points to the sitemap
- sitemap.xml: starter sitemap for the homepage

BEFORE UPLOADING:
1. Choose and register the school's real domain name and hosting service.
2. Upload the HTML file as index.html (rename it to index.html on your hosting server).
3. Upload robots.txt and sitemap.xml into the website root folder (same folder as index.html).
4. In BOTH robots.txt and sitemap.xml, replace YOUR-DOMAIN with the real domain, without adding a trailing slash.
5. Make sure the site is public and loads using HTTPS.
6. Add the domain to Google Search Console and verify ownership.
7. Submit https://YOUR-DOMAIN/sitemap.xml in Search Console > Sitemaps.
8. Use URL Inspection on the homepage and click Request Indexing.

NOTES:
- This package prepares the site for indexing; it does not publish the website online or guarantee a Google ranking.
- Search Console verification still requires access to the domain/hosting.
- Confirm the school's telephone number and all school facts before official publication.
